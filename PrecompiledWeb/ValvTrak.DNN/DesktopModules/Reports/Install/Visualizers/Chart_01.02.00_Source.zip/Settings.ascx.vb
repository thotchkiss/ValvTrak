'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Collections.Generic
Imports System.IO
Imports System.Web.UI

Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.UI.Utilities
Imports DotNetNuke.Modules.Reports.Extensions

Namespace DotNetNuke.Modules.Reports.Visualizers.Chart

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Settings class manages Chart Visualizer Settings
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Settings
        Inherits ReportsSettingsBase

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            ReportsClientAPI.Import(Me.Page)
            If Not ClientAPI.BrowserSupportsFunctionality(ClientAPI.ClientFunctionality.DHTML) Then
                Me.radColorPerBarMode.AutoPostBack = True
                Me.radOneColorMode.AutoPostBack = True
                AddHandler radColorPerBarMode.CheckedChanged, AddressOf ColorModeChanged
                AddHandler radOneColorMode.CheckedChanged, AddressOf ColorModeChanged
            Else
                SetupControls()
            End If
        End Sub

        Public Overrides Sub LoadSettings(ByVal VisualizerSettings As Dictionary(Of String, String))
            Me.rblChartType.SelectedValue = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_Type, "Bar")
            Me.txtHeight.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Height, String.Empty)
            Me.txtWidth.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Width, String.Empty)
            Me.txtXAxisTitle.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_XAxisTitle, String.Empty)
            Me.txtYAxisTitle.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_YAxisTitle, String.Empty)
            Me.txtBarNameColumn.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_BarNameColumn, String.Empty)
            Me.txtBarValueColumn.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_BarValueColumn, String.Empty)

            Dim colorMode As String = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_ColorMode, "OneColor")
            If colorMode.Equals("OneColor", StringComparison.OrdinalIgnoreCase) Then
                Me.radOneColorMode.Checked = True
                Me.radColorPerBarMode.Checked = False
            ElseIf colorMode.Equals("ColorPerBar", StringComparison.OrdinalIgnoreCase) Then
                Me.radColorPerBarMode.Checked = True
                Me.radOneColorMode.Checked = False
            End If
            UpdateColorMode()

            Me.txtBarColorColumn.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_BarColorColumn, String.Empty)
            Me.txtBarColor.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Chart_BarColor, "#000000")
            Me.spanColorPreview.Style(HtmlTextWriterStyle.BackgroundColor) = Me.txtBarColor.Text
        End Sub

        Public Overrides Sub SaveSettings(ByVal VisualizerSettings As Dictionary(Of String, String))
            VisualizerSettings(ReportsController.SETTING_Chart_Type) = Me.rblChartType.SelectedValue
            VisualizerSettings(ReportsController.SETTING_Height) = Me.txtHeight.Text
            VisualizerSettings(ReportsController.SETTING_Width) = Me.txtWidth.Text
            VisualizerSettings(ReportsController.SETTING_Chart_XAxisTitle) = Me.txtXAxisTitle.Text
            VisualizerSettings(ReportsController.SETTING_Chart_YAxisTitle) = Me.txtYAxisTitle.Text
            VisualizerSettings(ReportsController.SETTING_Chart_BarNameColumn) = Me.txtBarNameColumn.Text
            VisualizerSettings(ReportsController.SETTING_Chart_BarValueColumn) = Me.txtBarValueColumn.Text
            VisualizerSettings(ReportsController.SETTING_Chart_ColorMode) = GetColorMode()
            VisualizerSettings(ReportsController.SETTING_Chart_BarColorColumn) = Me.txtBarColorColumn.Text
            VisualizerSettings(ReportsController.SETTING_Chart_BarColor) = GetColorString(Me.txtBarColor.Text)
        End Sub

        Private Function GetColorString(ByVal ColorTextValue As String) As String
            Dim sColor As String = ColorTextValue
            If String.IsNullOrEmpty(sColor) Then
                Return "#000000"
            End If
            If Not sColor.StartsWith("#") Then
                sColor = String.Concat("#", sColor)
            End If
            If sColor.Length <> 4 AndAlso sColor.Length <> 7 Then
                Return "#000000"
            End If
            For i As Integer = 1 To sColor.Length - 1
                If "0123456789abcdefABCDEF".IndexOf(sColor(i)) = -1 Then
                    Return "#000000"
                End If
            Next i
            Return sColor
        End Function
        Private Function GetColorMode() As String
            If Me.radOneColorMode.Checked Then
                Return "OneColor"
            ElseIf Me.radColorPerBarMode.Checked Then
                Return "ColorPerBar"
            Else
                Return String.Empty
            End If
        End Function

        Private Sub SetupControls()
            ReportsClientAPI.RegisterBarColorModeSwitching(radOneColorMode, radColorPerBarMode, rowColor, rowColorColumn)
            ReportsClientAPI.RegisterColorPreview(txtBarColor, spanColorPreview)
        End Sub

        Private Sub UpdateColorMode()
            If radOneColorMode.Checked Then
                Me.rowColorColumn.Style(HtmlTextWriterStyle.Display) = "none"
                Me.rowColor.Style(HtmlTextWriterStyle.Display) = ""
            ElseIf radColorPerBarMode.Checked Then
                Me.rowColor.Style(HtmlTextWriterStyle.Display) = "none"
                Me.rowColorColumn.Style(HtmlTextWriterStyle.Display) = ""
            End If
        End Sub

        Private Sub ColorModeChanged(ByVal sender As Object, ByVal args As EventArgs)
            UpdateColorMode()
        End Sub

    End Class

End Namespace
