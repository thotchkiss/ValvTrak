'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Web.UI
Imports System.Collections.Generic
Imports System.Reflection
Imports System

Imports DotNetNuke
Imports DotNetNuke.Common.Utilities
Imports UISkin = DotNetNuke.UI.Skins.Skin

Namespace DotNetNuke.Modules.Reports.Visualizers.Chart

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Visualizer class displays the chart
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Visualizer
        Inherits VisualizerControlBase

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            ' Get the report for this module and validate the query
            If Not Me.ValidateDataSource OrElse Not Me.ValidateResults() Then
                imgChart.Visible = False
            Else
                Dim cacheUrl As String = Me.ResolveUrl(String.Format("ChartImages/t{0}m{1}.chart.png", Me.TabModuleId, Me.ModuleId))
                Dim cacheFile As String = Server.MapPath(cacheUrl)
                If Not Me.FromCache OrElse Not System.IO.File.Exists(cacheFile) Then
                    ChartImageManager.RenderImage(Me.Report, Me.ReportResults, cacheFile, Me.ExtensionContext)
                End If
                imgChart.ImageUrl = cacheUrl
            End If
        End Sub

    End Class

End Namespace