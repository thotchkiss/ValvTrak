'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Drawing
Imports System.Web.UI
Imports System.Collections.Generic
Imports System.Reflection
Imports System
Imports System.IO

Imports DotNetNuke
Imports UISkin = DotNetNuke.UI.Skins.Skin
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Modules.Reports.Exceptions
Imports DotNetNuke.Modules.Reports.Extensions

Namespace DotNetNuke.Modules.Reports.Visualizers.Chart

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Manages rendering and caching chart images
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ChartImageManager

        Public Const MIME_ImagePng As String = "image/png"

        ' This Chart Renderer is pretty limited and is not very elegant code, but thanks
        ' to the extensible Visualizers system anyone could make a better one!        
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Processes the Chart Image request by rendering the image to a temporary file
        ''' and sending that file to the client        
        ''' </summary>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub RenderImage(ByVal Report As ReportInfo, ByVal ReportResults As DataTable, ByVal ImagePath As String, ByVal ExtensionContext As ExtensionContext)
            ' First, remove the old image if it exists
            If File.Exists(ImagePath) Then
                File.Delete(ImagePath)
            End If

            ' Load Settings
            Dim sChartType As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_Type, "Bar")
            Dim sXAxisTitle As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_XAxisTitle, String.Empty)
            Dim sYAxisTitle As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_YAxisTitle, String.Empty)
            Dim sBarNameCol As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_BarNameColumn, String.Empty)
            Dim sBarValCol As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_BarValueColumn, String.Empty)
            Dim sColorColumn As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_BarColorColumn, String.Empty)
            Dim sColor As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_BarColor, "#000000")
            Dim sHeight As String = SettingsUtil.GetDictionarySetting(Of Integer)(Report.VisualizerSettings, ReportsController.SETTING_Height, 200)
            Dim sWidth As String = SettingsUtil.GetDictionarySetting(Of Integer)(Report.VisualizerSettings, ReportsController.SETTING_Width, 200)
            Dim rectGraphPane As New RectangleF(0, 0, Int32.Parse(sWidth), Int32.Parse(sHeight))

            Dim sColorMode As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Chart_ColorMode, "OneColor")
            Dim bColorPerBar As Boolean = False
            If sColorMode.Equals("OneColor", StringComparison.OrdinalIgnoreCase) Then
                bColorPerBar = False
            ElseIf sColorMode.Equals("ColorPerBar", StringComparison.OrdinalIgnoreCase) Then
                bColorPerBar = True
            End If

            ' Create the Graph Pane
            Dim graphPane As New ZedGraph.GraphPane(rectGraphPane, Report.Title, sXAxisTitle, sYAxisTitle)
            Dim barLabels As New List(Of String)
            Dim iMax As Double = Int32.MinValue
            For i As Integer = 0 To ReportResults.Rows.Count - 1
                Dim row As DataRow = ReportResults.Rows(i)
                Dim dblBarVal As Double = 0.0
                Try
                    dblBarVal = GetColumnValue(Of Double)(row, ReportResults, sBarValCol, 0.0)
                Catch ex As FormatException
                    Dim rowValue As String = DotNetNuke.Services.Localization.Localization.GetString("None.Text")
                    If row(sBarValCol) IsNot Nothing Then
                        rowValue = row(sBarValCol).ToString()
                    End If
                    Throw New VisualizerException("ValueCouldNotBeConvertedToADouble.Text", _
                                                  ExtensionContext.ResolveExtensionResourcesPath("Visualizer.ascx.resx"), _
                                                  rowValue)
                End Try
                If dblBarVal > iMax Then iMax = dblBarVal
                Dim color As String = sColor
                If bColorPerBar Then color = GetColumnValue(Of String)(row, ReportResults, sColorColumn, "#000000")
                Dim bar As ZedGraph.BarItem = Nothing
                Dim clr As Color = Utilities.ParseColorString(color)
                Dim lbl As String = GetColumnValue(Of String)(row, ReportResults, sBarNameCol, String.Empty)
                Dim arrValue(ReportResults.Rows.Count) As Double
                arrValue(i) = dblBarVal
                barLabels.Add(lbl)
                If sChartType = "Bar" Then
                    bar = graphPane.AddBar(lbl, arrValue, Nothing, clr)
                    graphPane.BarSettings.Base = ZedGraph.BarBase.Y
                ElseIf sChartType = "Column" Then
                    bar = graphPane.AddBar(lbl, Nothing, arrValue, clr)
                    graphPane.BarSettings.Base = ZedGraph.BarBase.X
                End If
            Next
            graphPane.BarSettings.Type = ZedGraph.BarType.Stack
            graphPane.Legend.IsVisible = False

            Dim textAxis As ZedGraph.Axis = graphPane.XAxis
            Dim valueAxis As ZedGraph.Axis = graphPane.YAxis
            If sChartType = "Bar" Then
                textAxis = graphPane.YAxis
                valueAxis = graphPane.XAxis
            End If

            textAxis.MajorTic.IsBetweenLabels = True
            textAxis.Scale.TextLabels = barLabels.ToArray()
            textAxis.Type = ZedGraph.AxisType.Text
            If ReportResults.Columns(sBarValCol).DataType.Equals(GetType(Double)) Then
                valueAxis.Type = ZedGraph.AxisType.Linear
            Else
                valueAxis.Scale.MinorStep = 1
                valueAxis.Scale.MajorStep = 1
            End If
            valueAxis.Scale.Min = 0
            valueAxis.Scale.Max = iMax + 1

            Dim bm As New Bitmap(1, 1)
            Using g As Graphics = Graphics.FromImage(bm)
                graphPane.AxisChange(g)
            End Using

            graphPane.GetImage().Save(ImagePath, System.Drawing.Imaging.ImageFormat.Png)
        End Sub

        Private Shared Function GetColumnValue(Of T)(ByVal row As DataRow, ByVal table As DataTable, ByVal col As String, ByVal defaultValue As T) As T
            If Not table.Columns.Contains(col) Then
                Return defaultValue
            Else
                Return Convert.ChangeType(row(col), GetType(T))
            End If
        End Function

    End Class

End Namespace