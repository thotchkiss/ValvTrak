'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Collections.Generic
Imports System.IO
Imports System.Web.UI

Imports DotNetNuke
Imports DotNetNuke.UI.Utilities
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Modules.Reports.Extensions

Namespace DotNetNuke.Modules.Reports.Visualizers.ReportingServices

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Settings class manages Reporting Services Visualizer Settings
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Settings
        Inherits ReportsSettingsBase

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            If Not ClientAPI.BrowserSupportsFunctionality(ClientAPI.ClientFunctionality.DHTML) Then
                radLocal.AutoPostBack = True
                radServer.AutoPostBack = True
                AddHandler radLocal.CheckedChanged, AddressOf ModeChanged
                AddHandler radServer.CheckedChanged, AddressOf ModeChanged
            Else
                ReportsClientAPI.Import(Me.Page)
                ReportsClientAPI.ShowHideByRadioButtons(Me.Page, radLocal, radServer, tblLocal, tblRemote)
            End If

            For Each li As ListItem In cblShow.Items
                li.Text = LocalString(li.Attributes("ResourceKey"))
            Next

            UpdateTableRows()
        End Sub

        Public Overrides Sub LoadSettings(ByVal VisualizerSettings As Dictionary(Of String, String))
            If Not CheckPermissions() Then Return

            Dim sMode As String = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_RS_Mode, Null.NullString)
            If String.Equals(sMode, "Local", StringComparison.OrdinalIgnoreCase) Then
                radLocal.Checked = True
                radServer.Checked = False
            ElseIf String.Equals(sMode, "Server", StringComparison.OrdinalIgnoreCase) Then
                radLocal.Checked = False
                radServer.Checked = True
            End If

            Dim uiElementString As String = ReportsController.DEFAULT_RS_VisibleUIElements
            If VisualizerSettings.ContainsKey(ReportsController.SETTING_RS_VisibleUIElements) Then
                uiElementString = VisualizerSettings(ReportsController.SETTING_RS_VisibleUIElements)
            End If
            Dim sUIElements As String() = uiElementString.Split(","c)
            For Each uielem As String In sUIElements
                Dim li As ListItem = cblShow.Items.FindByValue(uielem)
                If li IsNot Nothing Then
                    li.Selected = True
                End If
            Next

            UpdateTableRows()

            ctlReport.Url = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_RS_LocalReportFile, Null.NullString)
            chkEnableExternalImages.Checked = SettingsUtil.GetDictionarySetting(Of Boolean)(VisualizerSettings, ReportsController.SETTING_RS_EnableExternalImages, False)
            chkEnableHyperlinks.Checked = SettingsUtil.GetDictionarySetting(Of Boolean)(VisualizerSettings, ReportsController.SETTING_RS_EnableHyperlinks, False)
            txtServerUrl.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_RS_ServerReportUrl, Null.NullString)
            txtServerReportPath.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_RS_ServerReportPath, Null.NullString)
            txtUserName.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_UserName, Null.NullString)
            Dim pass As String = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Password, Null.NullString)
            If Not String.IsNullOrEmpty(pass) Then
                lblPassword.ResourceKey = "lblChangePassword"
            End If
            txtDomain.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_RS_Domain, Null.NullString)
            txtHeight.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_Height, "500px")
            txtDataSourceName.Text = SettingsUtil.GetDictionarySetting(Of String)(VisualizerSettings, ReportsController.SETTING_RS_DataSourceName, "DataSource")
            ctlReport.DataBind()
        End Sub

        Public Overrides Sub SaveSettings(ByVal VisualizerSettings As Dictionary(Of String, String))
            If Not Me.ParentModule.UserInfo.IsSuperUser Then Return

            Dim sMode As String = String.Empty
            If radLocal.Checked Then
                sMode = "Local"
            ElseIf radServer.Checked Then
                sMode = "Server"
            End If

            Dim uiElementsBuilder As New StringBuilder()
            For Each li As ListItem In cblShow.Items
                If li.Selected Then
                    If uiElementsBuilder.Length > 0 Then
                        uiElementsBuilder.Append(",")
                    End If
                    uiElementsBuilder.Append(li.Value)
                End If
            Next

            VisualizerSettings(ReportsController.SETTING_RS_Mode) = sMode
            VisualizerSettings(ReportsController.SETTING_RS_DataSourceName) = txtDataSourceName.Text
            VisualizerSettings(ReportsController.SETTING_Height) = txtHeight.Text
            VisualizerSettings(ReportsController.SETTING_RS_LocalReportFile) = ctlReport.Url
            VisualizerSettings(ReportsController.SETTING_RS_ServerReportUrl) = txtServerUrl.Text
            VisualizerSettings(ReportsController.SETTING_RS_ServerReportPath) = txtServerReportPath.Text
            VisualizerSettings(ReportsController.SETTING_RS_VisibleUIElements) = uiElementsBuilder.ToString()
            VisualizerSettings(ReportsController.SETTING_RS_EnableExternalImages) = chkEnableExternalImages.Checked
            VisualizerSettings(ReportsController.SETTING_RS_EnableHyperlinks) = chkEnableHyperlinks.Checked
            VisualizerSettings(ReportsController.SETTING_UserName) = txtUserName.Text
            VisualizerSettings(ReportsController.SETTING_RS_Domain) = txtDomain.Text

            If Not String.IsNullOrEmpty(txtPassword.Text) Then
                VisualizerSettings(ReportsController.SETTING_Password) = txtPassword.Text
            End If
        End Sub

        Private Function CheckPermissions() As Boolean
            If Not Me.ParentModule.UserInfo.IsSuperUser Then
                AccessMultiView.SetActiveView(AccessDeniedView)
                Return False
            Else
                AccessMultiView.SetActiveView(SuperUserView)
                Return True
            End If
        End Function

        Private Sub UpdateTableRows()
            If radLocal.Checked Then
                tblRemote.Style(HtmlTextWriterStyle.Display) = "none"
                tblLocal.Style(HtmlTextWriterStyle.Display) = String.Empty
            ElseIf radServer.Checked Then
                tblRemote.Style(HtmlTextWriterStyle.Display) = String.Empty
                tblLocal.Style(HtmlTextWriterStyle.Display) = "none"
            End If
        End Sub

        Private Sub ModeChanged(ByVal sender As Object, ByVal args As EventArgs)
            UpdateTableRows()
        End Sub

        Protected Sub valDataSourceName_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles valDataSourceName.ServerValidate
            args.IsValid = False
            If Not Me.radLocal.Checked Then
                args.IsValid = True
            ElseIf Not String.IsNullOrEmpty(txtDataSourceName.Text) Then
                args.IsValid = True
            End If
            UpdateTableRows()
        End Sub

        Protected Sub valReportFile_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles valReportFile.ServerValidate
            args.IsValid = False
            If Not Me.radLocal.Checked Then
                args.IsValid = True
            ElseIf Not String.IsNullOrEmpty(ctlReport.Url) Then
                args.IsValid = True
            End If
            UpdateTableRows()
        End Sub

        Protected Sub varServerUrl_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles varServerUrl.ServerValidate
            args.IsValid = False
            If Not Me.radServer.Checked Then
                args.IsValid = True
            ElseIf Not String.IsNullOrEmpty(txtServerUrl.Text) Then
                args.IsValid = True
            End If
            UpdateTableRows()
        End Sub

        Protected Sub valServerReportPath_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles valServerReportPath.ServerValidate
            args.IsValid = False
            If Not Me.radServer.Checked Then
                args.IsValid = True
            ElseIf Not String.IsNullOrEmpty(txtServerReportPath.Text) Then
                args.IsValid = True
            End If
            UpdateTableRows()
        End Sub

        Protected Function LocalString(ByVal key As String) As String
            Return DotNetNuke.Services.Localization.Localization.GetString(key, Me.LocalResourceFile)
        End Function
    End Class

End Namespace
