'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports DotNetNuke.Services.Localization

Imports System.Web.UI
Imports System.Collections.Generic
Imports System.Reflection
Imports UISkin = DotNetNuke.UI.Skins.Skin

Namespace DotNetNuke.Modules.Reports.Visualizers.ReportingServices

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Visualizer class displays the Report
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial Class Visualizer
        Inherits VisualizerControlBase

        Public Overrides ReadOnly Property AutoExecuteReport() As Boolean
            Get
                ' Don't load report results if we don't need to
                Return False
            End Get
        End Property

#Region " Event Handlers "

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If IsFirstRun Then
                DataBind()
            End If
        End Sub

#End Region

#Region " Overrides "

        Public Overrides Sub DataBind()
            Me.LoadReport()

            ReportViewer.ExportContentDisposition = Microsoft.Reporting.WebForms.ContentDisposition.AlwaysAttachment
            ReportViewer.ShowCredentialPrompts = True
            ReportViewer.ShowParameterPrompts = True
            ConfigureViewerUI()

            Dim sMode As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_RS_Mode, "Local")
            If String.Equals(sMode, "Local", StringComparison.OrdinalIgnoreCase) Then
                ReportViewer.ProcessingMode = Microsoft.Reporting.WebForms.ProcessingMode.Local
                Dim sFileID As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_RS_LocalReportFile, String.Empty)
                Dim sPath As String = Utilities.MapFileIdPath(Me.ParentModule.PortalSettings, sFileID)
                Dim sDataSourceName As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_RS_DataSourceName, String.Empty)
                If Not String.IsNullOrEmpty(sDataSourceName) Then
                    ReportViewer.LocalReport.ReportPath = sPath
                    ReportViewer.LocalReport.EnableExternalImages = _
                        SettingsUtil.GetDictionarySetting(Of Boolean)(Report.VisualizerSettings, ReportsController.SETTING_RS_EnableExternalImages, False)
                    ReportViewer.LocalReport.EnableHyperlinks = _
                        SettingsUtil.GetDictionarySetting(Of Boolean)(Report.VisualizerSettings, ReportsController.SETTING_RS_EnableHyperlinks, False)
                    ReportViewer.AsyncRendering = True

                    Me.ExecuteReport()
                    ReportViewer.LocalReport.DataSources.Add(New Microsoft.Reporting.WebForms.ReportDataSource(sDataSourceName, Me.ReportResults))
                Else
                    If Me.ParentModule.IsEditable Then
                        UISkin.AddModuleMessage(Me.ParentModule, Localization.GetString("NoDataSource.Text", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    End If
                    ReportViewer.Visible = False
                    End If
            ElseIf String.Equals(sMode, "Server", StringComparison.OrdinalIgnoreCase) Then
                    ReportViewer.ProcessingMode = Microsoft.Reporting.WebForms.ProcessingMode.Remote
                    Dim sUrl As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_RS_ServerReportUrl, String.Empty)
                    Dim sPath As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_RS_ServerReportPath, String.Empty)
                    If Not String.IsNullOrEmpty(sUrl) AndAlso Not String.IsNullOrEmpty(sPath) Then
                        ReportViewer.ServerReport.ReportServerUrl = New Uri(sUrl)
                    ReportViewer.ServerReport.ReportPath = sPath

                    Dim sUserName As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_UserName, String.Empty)
                    Dim sPassword As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_Password, String.Empty)
                    Dim sDomain As String = SettingsUtil.GetDictionarySetting(Of String)(Report.VisualizerSettings, ReportsController.SETTING_RS_Domain, String.Empty)

                    If Not String.IsNullOrEmpty(sUserName) Then
                        ReportViewer.ServerReport.ReportServerCredentials = _
                            New ReportingServicesCredential(sUserName, sPassword, sDomain)
                    End If

                    End If
            End If
            ReportViewer.DataBind()
        End Sub

        Private Sub ConfigureViewerUI()
            Dim uiElementString As String = ReportsController.DEFAULT_RS_VisibleUIElements
            If Report.VisualizerSettings.ContainsKey(ReportsController.SETTING_RS_VisibleUIElements) Then
                uiElementString = Report.VisualizerSettings(ReportsController.SETTING_RS_VisibleUIElements)
            End If
            Dim uiElements As String() = uiElementString.Split(","c)
            ReportViewer.ShowBackButton = ArrayUtils.Contains(uiElements, "BackButton")
            ReportViewer.ShowDocumentMapButton = ArrayUtils.Contains(uiElements, "DocumentMapButton")
            ReportViewer.ShowExportControls = ArrayUtils.Contains(uiElements, "ExportControls")
            ReportViewer.ShowFindControls = ArrayUtils.Contains(uiElements, "FindControls")
            ReportViewer.ShowPageNavigationControls = ArrayUtils.Contains(uiElements, "NavigationControls")
            ReportViewer.ShowPrintButton = ArrayUtils.Contains(uiElements, "PrintButton")
            ReportViewer.ShowPromptAreaButton = ArrayUtils.Contains(uiElements, "PromptAreaButton")
            ReportViewer.ShowRefreshButton = ArrayUtils.Contains(uiElements, "RefreshButton")
            ReportViewer.ShowToolBar = ArrayUtils.Contains(uiElements, "ToolBar")
            ReportViewer.ShowZoomControl = ArrayUtils.Contains(uiElements, "ZoomControl")        
        End Sub

#End Region

    End Class

End Namespace