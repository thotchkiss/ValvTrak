1.You can send an e-mail to dnnsmart@gmail.com and tell us your invoice number. Then enter your Invoice Number in "license" page and click "Activate" button. After that, module will become activated within 24 hours automatically.

2.Our site is a good place to advertise for your site. After you purchase our product and use it on your site, we can add your logo and link address on our product sale page and demo site. Then it will help your site to increase audience and it also be helpful for our clients to see how our modules run on your site. This is a win-win result. If you're interested in this, please send an e-mail to dnnsmart@gmail.com to discuss with us.

3.If you're satisfied with our product and support, you can give us a good comment and rating on snowcovered. Any question, please e-mail us and we will give you the best support. Thank you.

4.User Manual Download Link:
http://www.dnnsmart.net/FreeDownloads.aspx#ec_doc
