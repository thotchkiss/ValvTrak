﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Rawson.Data.Model;

namespace Rawson.Data.Controllers
{

    /// <summary>
    /// Summary description for ChemicalPumpFormController
    /// </summary>
    public class ChemicalPumpFormController : BaseController<ChemicalPumpTest>
    {
        public ChemicalPumpFormController()
        {
        }
    }
}